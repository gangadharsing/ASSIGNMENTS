from django.contrib import admin
from .models import OTPLog

admin.site.register(OTPLog)


