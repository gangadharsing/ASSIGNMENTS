# EmailAuth

Email Auth is an OTP authentication module for Django built with Tailwind CSS.


### Signin Page 
![Signin Page](https://github.com/aritra1999/EmailAuth/blob/master/demo/login.png)

### Signup Page 
![Signup Page](https://github.com/aritra1999/EmailAuth/blob/master/demo/reg.png)
![Signup Page](https://github.com/aritra1999/EmailAuth/blob/master/demo/reg2.png)

### OTP Page 
![OTP Page](https://github.com/aritra1999/EmailAuth/blob/master/demo/otp.png)
